import { StoreObject } from "./types";

export const initialStore: StoreObject = {
  isOpened: {
    transactionsPending: false,
  }
};
