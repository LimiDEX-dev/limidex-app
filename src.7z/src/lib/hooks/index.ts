export { useOutsideAlerter } from './use-outside-alerter';
